# RSA-BVD > 2024-03-02 9:17pm
https://universe.roboflow.com/roshdy/rsa-bvd

Provided by a Roboflow user
License: CC BY 4.0

